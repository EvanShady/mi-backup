#include <QApplication>
#include <QWidget>
