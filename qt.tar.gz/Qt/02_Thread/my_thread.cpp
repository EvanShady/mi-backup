#include "my_thread.h"
#include <QThread>
#include <QDebug>

My_Thread::My_Thread(QObject *parent) : QObject(parent)
{

    isstop = false;
}
void My_Thread::dealtimer(){

    while(isstop==false){
        QThread::sleep(1);
        emit my_signals();
    qDebug()<<"子线程号"<<QThread::currentThread();
    }
}
void My_Thread::setisstop(bool is){

    isstop=is;
}


