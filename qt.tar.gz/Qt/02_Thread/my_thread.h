#ifndef MY_THREAD_H
#define MY_THREAD_H

#include <QObject>

class My_Thread : public QObject
{
    Q_OBJECT
public:
    explicit My_Thread(QObject *parent = nullptr);
    //线程处理函数
    void dealtimer();
    //给封装的数据赋值
    void setisstop(bool is);

signals:
    void my_signals();//信号

public slots:

private:
    bool isstop;
};

#endif // MY_THREAD_H
