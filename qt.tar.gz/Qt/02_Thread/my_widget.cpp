#include "my_widget.h"
#include "ui_my_widget.h"
#include <QDebug>

My_Widget::My_Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::My_Widget)
{
    ui->setupUi(this);
    //创建线程，不能指定对象
    m1= new My_Thread();
    //创建子线程，可以分配空间
    m2= new QThread(this);
    //把自定义的线程加入到子线程
    m1->moveToThread(m2);
    //处理自定义里的信号
    connect(m1,&My_Thread::my_signals,this,&My_Widget::dealsigels);
    //查看线程的号码
    qDebug()<<"主线程号"<<QThread::currentThread();
    //启动子线程的处理函数
    connect(this,&My_Widget::startthread,m1,&My_Thread::dealtimer,Qt::QueuedConnection);
    //以左上角的×键来关闭线程
    connect( this,&My_Widget::destroyed,this,&My_Widget::dealclose);
    //线程处理函数不允许处理图形化界面
    //connect的第五个参数的意义
    /*多线程的使用
     * 连接方式：默认，队列，直接
     * 默认的时候：如果是多线程，默认的是使用队列
     * 			如果是单线程，默认的是直接
     * 队列：槽函数所在的线程和接受者一样
     * 直接：槽函数所在的线程和发送者一样
     *
     */
}
My_Widget::~My_Widget()
{
    delete ui;
}

void My_Widget::on_pushButton_strat_clicked()
{
    if(m2->isRunning()==true){
        return;
    }
   //启动子线程，但没有启动线程函数
    m2->start();
    m1->setisstop(false);
    //不能直接调用处理线程的函数，直接的话导致线程处理和主线程是在同一个线程
    //通过信号来启动线程函数
    emit startthread();
}

void My_Widget::dealsigels(){
    //设置定时器
    static int i=0;
    i++;
    ui->lcdNumber->display(i);
}

void My_Widget::on_pushButton_close_clicked()
{
    //关闭线程
    if(m2->isRunning()==false){
        return ;
    }

    m1->setisstop(true);
    m2->quit();
    m2->wait();
}

void My_Widget::dealclose(){
    on_pushButton_close_clicked();
    delete  m1;

}
