#ifndef MY_WIDGET_H
#define MY_WIDGET_H

#include <QWidget>
#include "my_thread.h"
#include <QThread>

namespace Ui {
class My_Widget;
}

class My_Widget : public QWidget
{
    Q_OBJECT

public:
    explicit My_Widget(QWidget *parent = nullptr);
    ~My_Widget();
    void dealsigels();//处理信号
    void dealclose();//处理关闭

signals:
    void startthread();//启动子线程的信号

private slots:
    void on_pushButton_strat_clicked();

    void on_pushButton_close_clicked();

private:
    Ui::My_Widget *ui;

    My_Thread *m1;//自定义的线程不能指定父对象
    QThread *m2;

};

#endif // MY_WIDGET_H
