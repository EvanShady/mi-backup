#include "widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
{
    move(100,100);
}

Widget::~Widget()
{

}
