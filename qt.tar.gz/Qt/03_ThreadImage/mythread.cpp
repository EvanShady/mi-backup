#include "mythread.h"
#include <QPainter>
#include <QPen>//画笔
#include <QBrush>//画刷
#include <QImage>

MyThread::MyThread(QObject *parent) : QObject(parent)
{

}

void MyThread::image(){
    //绘画设备,指定大小
    QImage image(500,500,QImage::Format_ARGB32);
    //指定绘画设备
    QPainter p(&image);
    //定义五个点
    QPoint a[]{
        QPoint (qrand()%500,qrand()%500),
        QPoint (qrand()%500,qrand()%500),
        QPoint (qrand()%500,qrand()%500),
        QPoint (qrand()%500,qrand()%500),
        QPoint (qrand()%500,qrand()%500),
    };
    QPen pen;//声明画笔
    pen.setWidth(5);//设置宽度
    p.setPen(pen);//把画笔交给画家
    QBrush brush;//画刷
    brush.setStyle(Qt::SolidPattern);//画刷设置风格
    brush.setColor(Qt::yellow);//设置颜色
    p.setBrush(brush);
    p.drawPolygon(a,5);//多边形
    emit updateimage(image);
}
