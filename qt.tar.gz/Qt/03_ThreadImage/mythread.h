#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QObject>
#include <QPainter>
#include <QImage>

class MyThread : public QObject
{
    Q_OBJECT
public:
    explicit MyThread(QObject *parent = nullptr);
    //线程处理函数
    void image();

signals:
    void updateimage(QImage temp);//信号

public slots:
private:

};

#endif // MYTHREAD_H
