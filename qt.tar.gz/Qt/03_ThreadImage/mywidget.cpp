#include "mywidget.h"
#include "ui_mywidget.h"
#include <QPainter>
#include <QImage>

MyWidget::MyWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyWidget)
{
    ui->setupUi(this);
    m1=new MyThread();//自定义线程
    m2=new QThread(this);//子线程
    m1->moveToThread(m2);//把父线程移动到子线程
    m2->start();//开线程，但没有启动线程的处理函数
    connect(ui->pushButton,&QPushButton::pressed,m1,&MyThread::image);//线程函数
    connect(m1,&MyThread::updateimage,this,&MyWidget::getimage);//线程函数
    connect(this,&MyWidget::destroyed,this,&MyWidget::close);//关闭函数
}

MyWidget::~MyWidget()
{
    delete ui;
}

void MyWidget::paintEvent(QPaintEvent *event){//绘画事件

    QPainter p(this);
    p.drawImage(0,0,image);
}

void MyWidget::getimage(QImage temp){//获取子线程的绘画
    image=temp;
    update();//更新窗口,间接调用painterEvent事件
}
void MyWidget::close(){
    m2->quit();
    m2->wait();
    delete  m1;
}
