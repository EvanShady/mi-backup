#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QWidget>
#include "mythread.h"
#include <QThread>
#include <QImage>

namespace Ui {
class MyWidget;
}

class MyWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MyWidget(QWidget *parent = nullptr);
    ~MyWidget();
    //重写绘画事件
    void paintEvent(QPaintEvent *event);
    void getimage(QImage);//接受子线程的绘画
    void close();//关闭

private slots:
    void on_pushButton_clicked();

private:
    Ui::MyWidget *ui;
    QImage image;//对象
    MyThread *m1;//父线程
    QThread *m2;//子线程

};

#endif // MYWIDGET_H
