#include "mainwindow.h"
#include <QDebug>
#include <QMenuBar>//菜单栏
#include <QMenu>//菜单
#include <QAction>//添加动作
#include <QToolBar>//快捷键窗口
#include <QStatusBar>//状态栏
#include <QLabel>//标签
#include <QTextEdit>//文本编辑区
#include <QDockWidget>//浮动窗口

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    move(500,500);
    //菜单栏
    QMenuBar *m=menuBar();
    QMenu *pfile=m->addMenu("文件(F)");
    //添加菜单项,添加动作
    QAction *filenew = pfile->addAction("新建");
    connect(filenew ,&QAction::triggered,
            []()
             {
                qDebug()<<"新建被按下";
            }
            );
    pfile->addSeparator();
    QAction *fileopen = pfile->addAction("打开");
    QMenu *poppen=m->addMenu("编辑");
    QAction *pnewpoppen=poppen->addAction("编辑");
    connect(pnewpoppen,&QAction::triggered,
            []()
    {
       qDebug()<<"编辑被按下";
    }
    );
    //快捷键
    QToolBar *toobar=addToolBar("toobar");
    toobar->addAction(filenew);
    //状态栏
    QStatusBar *sbar=statusBar();
    QLabel *label =new QLabel (this);
    sbar->addWidget(new QLabel("2",this));
    sbar->addPermanentWidget(new QLabel("3",this));
    //核心控件
    QTextEdit *text=new QTextEdit(this);
    setCentralWidget(text);
    //给核心控件配置浮动窗口
    QDockWidget *dock=new QDockWidget(this);
    addDockWidget(Qt::LeftDockWidgetArea,dock);
    QTextEdit *text1=new QTextEdit(this);
    dock->setWidget(text1);
}

MainWindow::~MainWindow()
{
}
