#include "mainwindow.h"
#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QDebug>
#include <QMessageBox>
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    QMenuBar *mbar=menuBar();
    QMenu *m1=mbar->addMenu("文件");
    QAction *p1=m1->addAction("关于对话框");
    QMenu *m2=mbar->addMenu("编辑");
    connect(p1,&QAction::triggered,
            [=]()
            {
       QMessageBox::about(this,"about","关于Qt") ;
    }
    );
    QAction *p2=m1->addAction("问题对话框");
    connect(p2,&QAction::triggered,
            [=]()
            {
        int ret=QMessageBox::question(this,"test","ok?",
                                      QMessageBox::Ok |
                                      QMessageBox::Cancel
                                      );
        switch(ret){
        case QMessageBox::Ok :
            qDebug()<<"I am ok";
            break;
        case QMessageBox::Cancel :
            qDebug()<<"I am bad";
            break;
        default:
            break;
        }
    }
    );
    QAction *p3=m1->addAction("文件对话框");
    connect(p3,&QAction::triggered,
            [=]()
    {
        QFileDialog ::getOpenFileName(
                    this,
                    "open",
                    "/home",
                    "test(*.cpp *.md);;"
                    "file(*.md,*.*)"
                    );
    }
    );

}

MainWindow::~MainWindow()
{

}
