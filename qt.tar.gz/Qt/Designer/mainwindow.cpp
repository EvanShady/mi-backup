#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QCompleter>
#include <QStringList>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QString str=ui->lineEdit->text();//获取内容
    qDebug()<<str;//打印内容
    ui->lineEdit->setText("idet");//更改内容
    ui->lineEdit->setTextMargins(10,0,0,0);//设置方度
    //ui->lineEdit->setEchoMode(QLineEdit::Password);//把内容设置成密码模式
    QStringList cin;//声明字符串列表
    cin<<"Hello"<<"how are you"<<"heHe";
    QCompleter *com=new QCompleter(cin,this);//new 一个模型，并指向字符串列表
    com->setCaseSensitivity(Qt::CaseInsensitive);//为模型设置不区分大小写
    ui->lineEdit->setCompleter(com);//把模型设置进去
}

MainWindow::~MainWindow()
{
    delete ui;
}

