#include "mylabel.h"
#include <QMouseEvent>
#include <QEvent>
#include <QDebug>

Mylabel::Mylabel(QWidget *parent) : QLabel(parent)
{
    //追踪鼠标
    this->setMouseTracking(true);
}

void Mylabel::mousePressEvent(QMouseEvent *ev){
    int i=ev->x();
    int j=ev->y();
    QString str=QString("<center><h1>mouse press:(%1,%2)</h1></center>").arg(i).arg(j);
    this->setText(str);
    if(ev->button()==Qt::LeftButton){
       qDebug()<<"left";
    }else if(ev->button()==Qt::RightButton){
       qDebug()<<"right";
    }else if(ev->button()==Qt::MidButton){
       qDebug()<<"mid";
    }
}
void Mylabel::mouseReleaseEvent(QMouseEvent *ev){
    QString str=QString("<center><h1>mouse release:(%1,%2)</h1></center>").arg(ev->x()).arg(ev->y());
    //this->setText(str);
}
void Mylabel::mouseMoveEvent(QMouseEvent *ev){

    QString str=QString("<center><h1>mouse move:(%1,%2)</h1></center>").arg(ev->x()).arg(ev->y());
    //this->setText(str);
}
void Mylabel::enterEvent(QEvent *e){
    QString str=QString("<center><h1>Event:enter</h1></center>");
    this->setText(str);
}
void Mylabel::leaveEvent(QEvent *event){
    QString str=QString("<center><h1>Event:leave</h1></center>");
    this->setText(str);
}
