#include "widget.h"
#include "ui_widget.h"
#include <QKeyEvent>
#include <QDebug>
#include <QMessageBox>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

void Widget::keyPressEvent(QKeyEvent *event){
   qDebug()<<(char)event->key();
   if(event->key()==Qt::Key_A){
       qDebug()<<"Qt::Key_A";
   }else{
       qDebug()<<"Qt::BCDEFGU";
   }
}
void Widget::closeEvent(QCloseEvent *event){
   int test=QMessageBox ::question(this,"question","sure?",
                                   QMessageBox::Yes |
                                   QMessageBox::No) ;
   if(test==QMessageBox::Yes){
       event->accept();
   }else{
       event->ignore();
   }
}
Widget::~Widget()
{
    delete ui;
}
