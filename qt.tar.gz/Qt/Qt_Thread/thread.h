#ifndef THREAD_H
#define THREAD_H

#include <QThread>

class Thread : public QThread
{
    Q_OBJECT
public:
    explicit Thread(QObject *parent = nullptr);

protected:
    //虚函数(线程处理函数)
    //不能直接调用，通过start来间接调用
    void run();

signals:
    void datedone();//信号

public slots:
};

#endif // THREAD_H
