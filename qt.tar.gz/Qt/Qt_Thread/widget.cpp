#include "widget.h"
#include "ui_widget.h"
#include <QThread>
#include <QDebug>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    timer = new QTimer(this);
    t1= new Thread(this);
    connect(timer,&QTimer::timeout,
            [=]()
    {
        static int i=0;
        i++;
        ui->lcdNumber->display(i);

    }
    );
    connect(t1,&Thread::datedone,this,&Widget::dealdone);
    //按下窗口关闭按键会触发destoryed,
    connect( this,&Widget::destroyed,this,&Widget::stopthread);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_clicked()
{

    timer->start(100);
    t1->start();
    for(int i=0;i<100000;i++){}


}

void Widget::dealdone(){

    qDebug()<<"over";
    timer->stop();
}

void Widget::stopthread(){
    //停止线程
   t1->quit();
   //等待线程完成工作
   t1->wait();
}
