#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);
    tcpsocket=new QTcpSocket(this);
}

Form::~Form()
{
    delete ui;
}

void Form::on_pushButton_connect_clicked()
{
    QString str=ui->prot->text();//获取服务器端口号
    qint16 prot=ui->lineEdit_ip->text().toInt();//获取服务器ip
    tcpsocket->connectToHost(QHostAddress(str),prot);//自动与服务器连接
}
