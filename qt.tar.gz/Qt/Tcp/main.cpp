#include "tcp_serven.h"
#include <QApplication>
#include <form.h>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Tcp_serven w;
    w.show();
    Form from;
    from.show();

    return a.exec();
}
