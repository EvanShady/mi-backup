#include "tcp_serven.h"
#include "ui_tcp_serven.h"

Tcp_serven::Tcp_serven(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Tcp_serven)
{
    ui->setupUi(this);
    tcpserver=nullptr;
    tcpsocket=nullptr;
    tcpserver=new QTcpServer(this);
    tcpserver->listen(QHostAddress::Any,8888);
    setWindowTitle("8888");
    connect(tcpserver,&QTcpServer::newConnection,
            [=]()
    {
        tcpsocket=tcpserver->nextPendingConnection();//取出套接字
        //对方的信息
       QString str=tcpsocket->peerAddress().toString();
       qint16 port=tcpsocket->peerPort();
       QString s1=QString("{%1:%2}:链接成功").arg(str).arg(port);//拼接字符串
       ui->textEditRead->setText(s1);//把对方的信息设置在编辑区里
    connect(tcpsocket,&QTcpSocket::readyRead,
            [=]()
    {
        QByteArray array=tcpsocket->readAll();//接收内容
        ui->textEditRead->append(array);//在编辑区里把接收的内容追加进来
    }
    );
    }
    );
}

Tcp_serven::~Tcp_serven()
{
    delete ui;
}

void Tcp_serven::on_pushButton_clicked()
{
    if(tcpsocket==nullptr){
        return ;
    }
   QString str=ui->textEdit_2Writer->toPlainText();   //从编辑区获取内容
   tcpsocket->write(str.toUtf8().data());//发送内容,这里的套接字是上面用的，因为上面的套接字是可以自动找到对方

}




void Tcp_serven::on_pushButton_2_clicked()
{

    if(tcpsocket==nullptr){
        return ;
    }
   tcpsocket->disconnectFromHost();//主动和客户端断开链接
   tcpsocket->close();
}
