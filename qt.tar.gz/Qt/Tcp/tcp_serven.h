#ifndef TCP_SERVEN_H
#define TCP_SERVEN_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>

namespace Ui {
class Tcp_serven;
}

class Tcp_serven : public QWidget
{
    Q_OBJECT

public:
    explicit Tcp_serven(QWidget *parent = nullptr);
    ~Tcp_serven();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Tcp_serven *ui;
    QTcpServer *tcpserver;//监听的套接字
    QTcpSocket *tcpsocket;//通信的套接字
};

#endif // TCP_SERVEN_H
