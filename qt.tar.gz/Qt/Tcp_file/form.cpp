#include "form.h"
#include "ui_form.h"
#include <QDebug>
#include <QMessageBox>
#include <QHostAddress>

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);
    tcpsocket = new  QTcpSocket(this);
    isstart=true;
    connect( tcpsocket, &QTcpSocket::readyRead,
        [=]()
        {
        QByteArray array=tcpsocket->readAll();
        if(isstart==true){
            isstart=false;
            //擦开文件信息
            //初始化变量
            filename=QString(array).section("##",0,0);
            size=QString(array).section("##",1,1).toInt();
            revcsize=0;
           // 打开文件，并以只写的方式
            file.setFileName(filename);
            bool isok=file.open(QIODevice::WriteOnly);
            if(isok==false){
                qDebug()<<"文件打开失败";
            }
        }else{
            //写文件信息
            qint64 len=file.write(array);
            revcsize+=len;
            if(revcsize==size){
                file.close();
                QMessageBox::information(this,"完成","接收完成");
                tcpsocket->disconnectFromHost();
                tcpsocket->close();
            }
        }

    }
    );
}

Form::~Form()
{
    delete ui;
}

void Form::on_pushButton_clicked()
{
    QString str=ui->lineEdit_ip->text();
    quint16 port=ui->port->text().toInt();
   tcpsocket->connectToHost(QHostAddress(str),port);
}
