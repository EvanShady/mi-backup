#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QTcpSocket>
#include <QFile>

namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

private slots:
    void on_pushButton_clicked();

private:
    Ui::Form *ui;
    QTcpSocket *tcpsocket;

    QFile file;//文件对象
    QString filename;//文件名
    qint64 size;//文件大小
    qint64 revcsize;//已经接收文件的大小
    bool isstart;
};

#endif // FORM_H
