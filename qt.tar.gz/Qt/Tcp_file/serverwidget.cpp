#include "serverwidget.h"
#include "ui_serverwidget.h"
#include <QHostAddress>
#include <QFileDialog>//文件对话框
#include <QFile>//文件对象
#include <QDebug>
#include <QFileInfo>//文件信息

serverWidget::serverWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::serverWidget)
{
    ui->setupUi(this);
    //按钮初始化为黑的
    ui->pushButton_bye->setEnabled(false);
    ui->pushButton_send->setEnabled(false);
    //初始化服务器对象，并指定父对象==size)
    tcpserver = new QTcpServer(this);
    tcpserver->listen(QHostAddress::Any,8888);
    setWindowTitle("服务器的端口号为：8888");
    connect(tcpserver,&QTcpServer::newConnection,
            [=]()
            {
        //获取对方信息,并写到编辑器
        tcpsocket=tcpserver->nextPendingConnection();
        QString ip=tcpsocket->peerAddress().toString();
        quint16 port=tcpsocket->peerPort();
        QString str =QString("[%1:%2] 成功连接").arg(ip).arg(port);
        ui->textEdit->setText(str);
        //成功连接才能将选择文件变回来
        ui->pushButton_bye->setEnabled(true);
    }
    );
}

serverWidget::~serverWidget()
{
    delete ui;
}

void serverWidget::on_pushButton_bye_clicked()
{

    QString filepath=QFileDialog::getOpenFileName(this,"open","./home");
    if(filepath.isEmpty()==false){
        filename.clear();
        size=0;
        //获取文件的信息
        QFileInfo info(filepath);
        filename = info.fileName();
        size = info.size();
        //发送文件的大小
        sendsize=0;
        //以只读的形式打开文件
        //指定文件名
        file.setFileName(filepath);
        bool isok=file.open(QIODevice::ReadOnly);
        if(isok==false){
           qDebug()<<"以只读方式打开文件失败";
        }
        ui->pushButton_bye->setEnabled(false);//设置选择文件的按钮
       ui->pushButton_send->setEnabled(true) ;//设置发送的按钮
       ui->textEdit->append(filepath);//设置文件路径在文本编辑区
       connect(&timer,&QTimer::timeout,
               [=]()
       {
          timer.stop();//定时器关闭
          sendfile();//发生文件
       }
       );


    }else{
        qDebug()<<"选择文件失败";
    }
}

void serverWidget::on_pushButton_send_clicked()
{

    //先发生文件的头信息 [文件名##文件大小]
    QString str=QString("%1##%2").arg(filename).arg(size);
    qint64 len=tcpsocket->write(str.toUtf8());
    if(len>0){
        //再发送文件的内容
        //防止tcp粘包问题
        //通过定时器来调节
        timer.start(20);
    }else{
        qDebug()<<"头文件信息发送失败";
        file.close();
        ui->pushButton_bye->setEnabled(true);
        ui->pushButton_send->setEnabled(false);
    }
}

void serverWidget::sendfile(){

    qint64 len=0;
    do{
        //每次发生的数据
    char buf[5*1024]={0};
    len=0;
    len=file.read(buf,sizeof (buf));//每次读文件的大小
    len=tcpsocket->write(buf,len);//每次发的大小
    sendsize+=len;
    }while(len>0);
    if(size==sendsize){

        ui->textEdit->append("文件发生成功");
            file.close();
        //客户端断开
        tcpsocket->disconnectFromHost();
        tcpsocket->close();
    }

}
