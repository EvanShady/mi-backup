#ifndef SERVERWIDGET_H
#define SERVERWIDGET_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QFile>
#include <QTimer>

namespace Ui {
class serverWidget;
}

class serverWidget : public QWidget
{
    Q_OBJECT

public:
    explicit serverWidget(QWidget *parent = nullptr);
    void sendfile();
    ~serverWidget();

private slots:
    void on_pushButton_bye_clicked();

    void on_pushButton_send_clicked();

private:
    Ui::serverWidget *ui;
    QTcpServer *tcpserver;//监听套接字
    QTcpSocket *tcpsocket;//通信套接字

    QFile file;//文件对象
    QString filename;//文件名
    qint64 size;//文件大小
    qint64 sendsize;//已经发生文件的大小
    QTimer timer;//定时器
};

#endif // SERVERWIDGET_H
