#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QHostAddress>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    udpsocket=new QUdpSocket(this);//自动回收空间
    udpsocket->bind(8888);//绑定端口
    setWindowTitle("服务器的端口为：8888");
    //当对方成功发生信息过来，会自动调用readyRead;
    connect(udpsocket,&QUdpSocket::readyRead,
            [=]()
    {
        char buf[1024]={0};
        quint16 point;//对方的端口
       QHostAddress ip; //对方的地址
        qint64 len=udpsocket->readDatagram(buf,sizeof (buf),&ip,&point);
        if(len>0){
            QString str=QString("[%1:%2] %3").arg(ip.toString()).arg(point).arg(buf);
            ui->textEdit->setText(str);
        }
    }
    );
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_send_clicked()
{
  QString str=ui->lineEdit_ip->text();
  qint16 port=ui->lineEdit_port->text().toInt();
  QString temp=ui->textEdit->toPlainText();
  udpsocket->writeDatagram(temp.toUtf8().data(),QHostAddress(str),port);
}
