#include "widget.h"
#include "ui_widget.h"
#include <QPainter>
#include <QMouseEvent>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    setWindowFlags(Qt::FramelessWindowHint  | windowFlags());//去边框
    setAttribute(Qt::WA_TranslucentBackground);//把背景设为透明
}

Widget::~Widget()
{
    delete ui;
}

void Widget::paintEvent(QPaintEvent *event){
    QPainter p(this);
    p.drawPixmap(0,0,QPixmap("../pximap/test4.jpg"));
}
void Widget::mousePressEvent(QMouseEvent *event){
    if(event->button()==Qt::LeftButton){
        p=event->globalPos()-this->frameGeometry().topLeft();//求移动的差值
        //窗口全局变量减去当前移动点的位置
    }else{
        close();
    }
}
void Widget::mouseMoveEvent(QMouseEvent *event){
    if(event->buttons() &Qt::LeftButton){
        move(event->globalPos()-p);//窗口全局变量减去移动的差值
    }else{
        close();
    }
}

