/********************************************************************************
** Form generated from reading UI file 'my_widget.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MY_WIDGET_H
#define UI_MY_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_My_Widget
{
public:
    QPushButton *pushButton_strat;
    QPushButton *pushButton_close;
    QLCDNumber *lcdNumber;

    void setupUi(QWidget *My_Widget)
    {
        if (My_Widget->objectName().isEmpty())
            My_Widget->setObjectName(QString::fromUtf8("My_Widget"));
        My_Widget->resize(400, 300);
        pushButton_strat = new QPushButton(My_Widget);
        pushButton_strat->setObjectName(QString::fromUtf8("pushButton_strat"));
        pushButton_strat->setGeometry(QRect(60, 220, 101, 36));
        pushButton_close = new QPushButton(My_Widget);
        pushButton_close->setObjectName(QString::fromUtf8("pushButton_close"));
        pushButton_close->setGeometry(QRect(240, 220, 101, 36));
        lcdNumber = new QLCDNumber(My_Widget);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));
        lcdNumber->setGeometry(QRect(100, 80, 211, 91));

        retranslateUi(My_Widget);

        QMetaObject::connectSlotsByName(My_Widget);
    } // setupUi

    void retranslateUi(QWidget *My_Widget)
    {
        My_Widget->setWindowTitle(QCoreApplication::translate("My_Widget", "My_Widget", nullptr));
        pushButton_strat->setText(QCoreApplication::translate("My_Widget", "strat", nullptr));
        pushButton_close->setText(QCoreApplication::translate("My_Widget", "close", nullptr));
    } // retranslateUi

};

namespace Ui {
    class My_Widget: public Ui_My_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MY_WIDGET_H
