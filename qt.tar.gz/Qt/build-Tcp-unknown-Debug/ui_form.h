/********************************************************************************
** Form generated from reading UI file 'form.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORM_H
#define UI_FORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form
{
public:
    QGridLayout *gridLayout;
    QLabel *label;
    QLineEdit *prot;
    QPushButton *pushButton_connect;
    QLabel *label_2;
    QLineEdit *lineEdit_ip;
    QTextEdit *textEditRead;
    QTextEdit *textEdit_Write;
    QPushButton *pushButton_send;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_close;

    void setupUi(QWidget *Form)
    {
        if (Form->objectName().isEmpty())
            Form->setObjectName(QString::fromUtf8("Form"));
        Form->resize(443, 437);
        gridLayout = new QGridLayout(Form);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(Form);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        prot = new QLineEdit(Form);
        prot->setObjectName(QString::fromUtf8("prot"));

        gridLayout->addWidget(prot, 0, 1, 1, 1);

        pushButton_connect = new QPushButton(Form);
        pushButton_connect->setObjectName(QString::fromUtf8("pushButton_connect"));

        gridLayout->addWidget(pushButton_connect, 0, 2, 2, 2);

        label_2 = new QLabel(Form);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        lineEdit_ip = new QLineEdit(Form);
        lineEdit_ip->setObjectName(QString::fromUtf8("lineEdit_ip"));

        gridLayout->addWidget(lineEdit_ip, 1, 1, 1, 1);

        textEditRead = new QTextEdit(Form);
        textEditRead->setObjectName(QString::fromUtf8("textEditRead"));
        textEditRead->setReadOnly(true);

        gridLayout->addWidget(textEditRead, 2, 0, 1, 4);

        textEdit_Write = new QTextEdit(Form);
        textEdit_Write->setObjectName(QString::fromUtf8("textEdit_Write"));

        gridLayout->addWidget(textEdit_Write, 3, 0, 1, 4);

        pushButton_send = new QPushButton(Form);
        pushButton_send->setObjectName(QString::fromUtf8("pushButton_send"));

        gridLayout->addWidget(pushButton_send, 4, 0, 1, 1);

        horizontalSpacer = new QSpacerItem(96, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 4, 2, 1, 1);

        pushButton_close = new QPushButton(Form);
        pushButton_close->setObjectName(QString::fromUtf8("pushButton_close"));

        gridLayout->addWidget(pushButton_close, 4, 3, 1, 1);


        retranslateUi(Form);

        QMetaObject::connectSlotsByName(Form);
    } // setupUi

    void retranslateUi(QWidget *Form)
    {
        Form->setWindowTitle(QCoreApplication::translate("Form", "Form", nullptr));
        label->setText(QCoreApplication::translate("Form", "\346\234\215\345\212\241\345\231\250\347\253\257\345\217\243\357\274\232", nullptr));
        prot->setText(QCoreApplication::translate("Form", "8888", nullptr));
        pushButton_connect->setText(QCoreApplication::translate("Form", "connect", nullptr));
        label_2->setText(QCoreApplication::translate("Form", "\343\200\201\346\234\215\345\212\241\345\231\250ip\357\274\232`", nullptr));
        lineEdit_ip->setText(QCoreApplication::translate("Form", "127.0.0.1", nullptr));
        pushButton_send->setText(QCoreApplication::translate("Form", "send", nullptr));
        pushButton_close->setText(QCoreApplication::translate("Form", "close", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Form: public Ui_Form {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORM_H
