/********************************************************************************
** Form generated from reading UI file 'tcp_serven.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TCP_SERVEN_H
#define UI_TCP_SERVEN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Tcp_serven
{
public:
    QGridLayout *gridLayout;
    QTextEdit *textEditRead;
    QTextEdit *textEdit_2Writer;
    QPushButton *pushButton;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_2;

    void setupUi(QWidget *Tcp_serven)
    {
        if (Tcp_serven->objectName().isEmpty())
            Tcp_serven->setObjectName(QString::fromUtf8("Tcp_serven"));
        Tcp_serven->resize(400, 300);
        gridLayout = new QGridLayout(Tcp_serven);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        textEditRead = new QTextEdit(Tcp_serven);
        textEditRead->setObjectName(QString::fromUtf8("textEditRead"));
        textEditRead->setReadOnly(true);

        gridLayout->addWidget(textEditRead, 0, 0, 1, 3);

        textEdit_2Writer = new QTextEdit(Tcp_serven);
        textEdit_2Writer->setObjectName(QString::fromUtf8("textEdit_2Writer"));

        gridLayout->addWidget(textEdit_2Writer, 1, 0, 1, 3);

        pushButton = new QPushButton(Tcp_serven);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 2, 0, 1, 1);

        horizontalSpacer = new QSpacerItem(205, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 2, 1, 1, 1);

        pushButton_2 = new QPushButton(Tcp_serven);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        gridLayout->addWidget(pushButton_2, 2, 2, 1, 1);


        retranslateUi(Tcp_serven);

        QMetaObject::connectSlotsByName(Tcp_serven);
    } // setupUi

    void retranslateUi(QWidget *Tcp_serven)
    {
        Tcp_serven->setWindowTitle(QCoreApplication::translate("Tcp_serven", "Tcp_serven", nullptr));
        pushButton->setText(QCoreApplication::translate("Tcp_serven", "send", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Tcp_serven", "close", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Tcp_serven: public Ui_Tcp_serven {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TCP_SERVEN_H
