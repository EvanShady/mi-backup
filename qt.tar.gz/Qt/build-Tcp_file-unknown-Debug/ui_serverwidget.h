/********************************************************************************
** Form generated from reading UI file 'serverwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.13.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SERVERWIDGET_H
#define UI_SERVERWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_serverWidget
{
public:
    QGridLayout *gridLayout;
    QSpacerItem *horizontalSpacer;
    QLabel *label;
    QSpacerItem *horizontalSpacer_2;
    QTextEdit *textEdit;
    QPushButton *pushButton_bye;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButton_send;

    void setupUi(QWidget *serverWidget)
    {
        if (serverWidget->objectName().isEmpty())
            serverWidget->setObjectName(QString::fromUtf8("serverWidget"));
        serverWidget->resize(540, 462);
        QFont font;
        font.setPointSize(18);
        serverWidget->setFont(font);
        gridLayout = new QGridLayout(serverWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        horizontalSpacer = new QSpacerItem(213, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer, 0, 0, 1, 2);

        label = new QLabel(serverWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label, 0, 2, 1, 1);

        horizontalSpacer_2 = new QSpacerItem(206, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_2, 0, 3, 1, 2);

        textEdit = new QTextEdit(serverWidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));

        gridLayout->addWidget(textEdit, 1, 0, 1, 5);

        pushButton_bye = new QPushButton(serverWidget);
        pushButton_bye->setObjectName(QString::fromUtf8("pushButton_bye"));

        gridLayout->addWidget(pushButton_bye, 2, 0, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(289, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_3, 2, 1, 1, 3);

        pushButton_send = new QPushButton(serverWidget);
        pushButton_send->setObjectName(QString::fromUtf8("pushButton_send"));

        gridLayout->addWidget(pushButton_send, 2, 4, 1, 1);


        retranslateUi(serverWidget);

        QMetaObject::connectSlotsByName(serverWidget);
    } // setupUi

    void retranslateUi(QWidget *serverWidget)
    {
        serverWidget->setWindowTitle(QCoreApplication::translate("serverWidget", "serverWidget", nullptr));
        label->setText(QCoreApplication::translate("serverWidget", "\346\234\215\345\212\241\345\231\250", nullptr));
        pushButton_bye->setText(QCoreApplication::translate("serverWidget", "\351\200\211\346\213\251\346\226\207\344\273\266", nullptr));
        pushButton_send->setText(QCoreApplication::translate("serverWidget", "\345\217\221\347\224\237\346\226\207\344\273\266", nullptr));
    } // retranslateUi

};

namespace Ui {
    class serverWidget: public Ui_serverWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SERVERWIDGET_H
