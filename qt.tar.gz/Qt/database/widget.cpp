#include "widget.h"
#include "ui_widget.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QMessageBox>
#include <QSqlError>



Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    qDebug()<<QSqlDatabase::drivers();//打印QT支持的数据库的名字
    QSqlDatabase ad=QSqlDatabase::addDatabase("QMYSQL");//添加数据库
    ad.setHostName("127.0.0.1");//ip地址
    ad.setUserName("root");//名字
    ad.setPassword("123456");//密码
    ad.setDatabaseName("info");//使用哪个数据库
    //数据库打开失败
    if(!ad.open()){
        QMessageBox::warning(this,"open",ad.lastError().text());
        return;
    }
}

Widget::~Widget()
{
    delete ui;
}
