#include "my_widget.h"
#include <QApplication>
#include <QPushButton>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QPushButton b;
    my_Widget w;
    w.show();
    return a.exec();
}
