#include "my_widget.h"
#include <QString>
#include <QDebug>

my_Widget::my_Widget(QWidget *parent)
    : QWidget(parent)
{
    b1.setParent(this);
    b1.setText("close");
    b1.move(101,101);
    b2=new QPushButton (this);
    b2->setText("abc");
    connect(&b1,&QPushButton::pressed,this,&QPushButton::close);
    connect(b2,&QPushButton::released,&b1,&QPushButton::hide);
    this->setWindowTitle("老大") ;
    b3.setParent(this);
    b3.setText("切换子窗口");
    b3.move(50,50);
    s.show();
    connect(&b3,&QPushButton::released,this,&my_Widget::showwid);
    connect(&s,&sud::xin,this,&my_Widget::showxin);//检查信号发送的成功并处理信号
    void (sud::*a)(int ,QString)=&sud::testxin;
    connect(&s,a,this,&my_Widget::showxin2);//检查信号发送的成功并处理信号
    QPushButton *b5=new QPushButton (this);
    b5->setText("lambda");
    b5->move(150,150);
    int c=19,b=10;
    connect(b5,&QPushButton::released,[=]()
    {
        b5->setText("表达式");
        qDebug()<<c<<b;
    }
    );

    resize(400,300);//窗口的高度和宽度
}
void my_Widget::showxin2(int a,QString str){
    qDebug()<<a<<str;
}
void my_Widget::test(){
    b2->setText("123");
}
void my_Widget::showwid(){
    s.show();
    this->hide();
}
void my_Widget::showxin(){
    this->show();
    s.hide();
}

my_Widget::~my_Widget()
{

}
