#ifndef MY_WIDGET_H
#define MY_WIDGET_H

#include <QWidget>
#include <QPushButton>
#include <QString>
#include "sud.h"
class my_Widget : public QWidget
{
    Q_OBJECT

public:
    my_Widget(QWidget *parent = nullptr);
    ~my_Widget();
    void test();
    void showwid();
    void showxin();
    void showxin2(int a,QString str);
private:
    QPushButton b1;
    QPushButton *b2;
    QPushButton b3;
    sud s;
};

#endif // MY_WIDGET_H
