#include "sud.h"

sud::sud(QWidget *parent) : QWidget(parent)
{
    this->setWindowTitle("小弟");
    b.setParent(this);
    b.setText("切换父窗口");
    connect(&b,&QPushButton::clicked,this,&sud::showwid);//发送信号
    resize(400,300);//窗口的高度和宽度
}
void sud::showwid(){
    emit xin();
    emit testxin(200,"你好，世界");
}
