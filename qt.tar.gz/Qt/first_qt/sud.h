#ifndef SUD_H
#define SUD_H

#include <QWidget>
#include <QPushButton>
#include <QString>

class sud : public QWidget
{
    Q_OBJECT
public:
    explicit sud(QWidget *parent = nullptr);
    void showwid();
signals:
    void xin();
    void testxin(int a,QString str);

public slots:
private:
    QPushButton b;
};

#endif // SUD_H
