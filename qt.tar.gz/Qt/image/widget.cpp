#include "widget.h"
#include "ui_widget.h"
#include <QPainter>
#include <QPixmap>
#include <QImage>
#include <QPicture>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    QImage image(400,300,QImage::Format_RGB32);//绘画工具
    QPainter p(&image);//画家
    p.drawImage(0,0,QImage(QImage("../pximap/test2.jpg")));//画照片
    for(int i=0;i<50;i++){//对绘画设备的像素点的更改
        for(int j=0;j<50;j++){
            image.setPixel(i,j,qRgb(0,255,0));
        }
    }
    image.save("../xiaoxin.jpg");//保存图片
}

Widget::~Widget()
{
    delete ui;
}
