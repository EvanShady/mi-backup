#include "widget.h"
#include "ui_widget.h"
#include <QPainter>
#include <QPen>
#include <QBrush>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    x=0;
}

Widget::~Widget()
{
    delete ui;
}
void Widget::paintEvent(QPaintEvent *){
    QPainter p (this);//画家
    QPen pen;//画笔
    QBrush brush;//填充
    brush.setColor(Qt::yellow);//填充颜色
    brush.setStyle(Qt::Dense1Pattern);//填充风格
    p.setBrush(brush);//给画家设置填充
    pen.setWidth(10);//设置画笔的大小
   // pen.setColor(Qt::yellow);
    pen.setColor(QColor(166,166,166));//给画笔设置颜色(rgb)
    pen.setStyle(Qt::DashDotDotLine);//给画笔设置风格
    p.setPen(pen);//给画家设置画笔
    //p.drawPixmap(0,0,width(),height(),QPixmap(":/new/prefix1/bizhi 1.jpeg"));
    p.drawPixmap(rect(),QPixmap(":/new/prefix1/bizhi 1.jpeg"));//设置背景画
    p.drawLine(50,50,100,50);//画线
    p.drawLine(50,50,50,100);//画线
    p.drawRect(200,200,110,110);//画矩形
    p.drawEllipse(QPoint(105,105),50,50);//画圆
    p.drawPixmap(x,180,50,50,QPixmap(":/new/prefix1/头像.jpeg"));//画奔跑的小新
}

void Widget::on_pushButton_clicked()
{
    x+=100;
    if(x>width()){
        x=0;
    }
    update();//刷新窗口的，简称(重绘)
}
