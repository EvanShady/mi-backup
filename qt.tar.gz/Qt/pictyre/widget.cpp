#include "widget.h"
#include "ui_widget.h"
#include <QPicture>
#include <QPainter>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    QPicture pic;
    QPainter p;
    p.begin(&pic);
    p.drawPixmap(0,0,400,400,QPixmap("../pximap/test9.jpg"));
    p.drawLine(100,100,200,100);
    p.end();
    pic.save("../pic.png");
}

Widget::~Widget()
{
    delete ui;
}

void Widget::paintEvent(QPaintEvent *event){
#if 0
    QPicture pic;
    pic.load("../pic.png");
    QPainter p(this);
    p.drawPicture(0,0,pic);
#endif
    QPixmap pix;
    pix.load("../pximap/test9.jpg");//加载图片进来
    QImage image=pix.toImage();//把绘画工具转换成image
   QPainter p(this);//定义画家
   p.drawImage(0,0,image);//画照片
   //把QImage 转换成Qpixmap
   QImage im;
   im.load("../pximap/test9.jpg");
   QPixmap pi=QPixmap::fromImage(image);//这里是把前面的image重新转换成pixmap
   p.drawPixmap(600,600,300,300,pi);
}
