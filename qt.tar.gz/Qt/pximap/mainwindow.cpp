#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPixmap>
#include <QImage>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPixmap pixmap(400,300);//绘画工具
    QPainter pa(&pixmap);//画家
    pixmap.fill(Qt::red);//填充背景色
    pa.drawPixmap(0,0,400,300,QPixmap("../pximap/test.jpeg"));//画照片
    pixmap.save("xiaoxin/jpeg");//保存为照片
}

MainWindow::~MainWindow()
{
    delete ui;
}
