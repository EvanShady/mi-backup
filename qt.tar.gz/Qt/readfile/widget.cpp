#include "widget.h"
#include "ui_widget.h"
#include <QFile>
#include <QFileDialog>
#include <QTextEdit>
#include <QFileInfo>
#include <QDebug>
#include <QDateTime>
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_buttonread_clicked()
{
    QString str=QFileDialog::getOpenFileName(this,"open","../","TXT(*.txt)");
    if(!str.isEmpty()){//判断是否打开文档
        QFile file(str);//定义文件对象
        bool isok=file.open(QIODevice::ReadOnly);//设置文件是以只读的方式
    if(isok==true){//判断文件的内容有没有
#if 0
        QByteArray array=file.readAll();//以文件全部内容一次性的录入
        ui->textEdit->setText(array);
#endif
        QByteArray array;
        while(!file.atEnd()){
            array+=file.readLine();
        }
        ui->textEdit->setText(array);
        }
    file.close();
    QFileInfo info(str);
    qDebug()<<"文件名字"<<info.fileName();
    qDebug()<<"文件大小"<<info.size();
    qDebug()<<"文件后缀"<<info.suffix();
    qDebug()<<"文件创建时间"<<info.created().toString("yyyy-MM-dd hh::mm::ss");

    }
}

void Widget::on_buttionwrite_clicked()
{
    QString stre=QFileDialog::getSaveFileName(this,"save","../");//文件打开的对话框
    if(!stre.isEmpty()){
        QFile file(stre);
        bool isok=file.open(QIODevice::WriteOnly);
        if(isok==true){
            QString strel=ui->textEdit->toPlainText();//在文本编辑器的地方提取内容
            file.write(strel.toUtf8());//写文件以Utf8的形式写进
        }
    }
}
