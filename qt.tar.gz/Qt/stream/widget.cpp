#include "widget.h"
#include "ui_widget.h"
#include <QFile>
#include <QDataStream>
#include <QDebug>

#define cout qDebug()<<"{"<<__FILE__<<":"<<__BASE_FILE__<<"}"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    writefile();
    readfile();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::writefile(){
    QFile file("../test1.txt");
    bool isok=file.open(QIODevice::WriteOnly);
    if(isok==true){
        QDataStream stream(&file);
        stream<<QString("主要看气质")<<250;
    file.close();
    }
}
void Widget::readfile(){

    QFile file("../test1.txt");
    bool isok=file.open(QIODevice::ReadOnly);
    if(isok==true){
        QDataStream stream(&file);
        QString str;
        int a;
        stream>>str >>a;
        qDebug()<<str.toUtf8().data()<<a;
        cout<<str.toUtf8().data() <<a;
    file.close();
    }
}
