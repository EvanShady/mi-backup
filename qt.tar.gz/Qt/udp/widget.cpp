#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    udpsocket = new QUdpSocket(this);
    udpsocket->bind(8000);
    setWindowTitle("服务器的端口为8000");
    connect(udpsocket,&QUdpSocket::readyRead,
            [=]()
        {
        char buf[1024]={0};
        QHostAddress ip;
        quint16 port;
        qint64 temp=udpsocket->readDatagram(buf,sizeof (buf),&ip,&port);
        //格式化
        QString str=QString("[%1:%2] %3").arg(ip.toString()).arg(port).arg(buf);
        ui->textEdit->setText(str);
    }
    );
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_send_clicked()
{
   QString str=ui->lineEdit_ip->text();
   qint16 port=ui->lineEdit_port->text().toInt();
   QString s1=ui->textEdit->toPlainText();
   udpsocket->writeDatagram(s1.toUtf8().data(),QHostAddress(str),port);
}
