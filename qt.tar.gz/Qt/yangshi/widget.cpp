#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->label->setStyleSheet("Qlabel{color:rgb(0,255,255);"
                             "backgroud-color:blue;"
                             "border-image:url(:/new/prefix1/头像.jpeg)"
                             "}");
    ui->pushButton->setStyleSheet("QPushButton{"
                                  "border: 2px outset green;"
                             "border-image:url(:/new/prefix1/头像.jpeg);"
                                  "}"
                                  "QPushButton:hover{"
                                  "border-image:url(:/MyBlog/source/_posts/test/a.jpg);"
                                  "}"
                                  "QPushButton:pressed{"
                                  "border-image:url(:/MyBlog/source/_posts/test2/desktop.jpg);"
                                  "}"
                                  );
}

Widget::~Widget()
{
    delete ui;
}
